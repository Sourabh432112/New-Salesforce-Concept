import { LightningElement,track } from 'lwc';
export default class AdddressInfo extends LightningElement {
    @track address ={
        street:'',
        city:'',
        state:'',
        postalCode:null
    };
    handleChange(event){
        console.log('name--',event.target.name);
        console.log('value--',event.target.value);
        this.address[event.target.name] = event.target.value;
        console.log('name---',this.address[event.target.name]);
    }
    handleSave(){
        console.log('this.address---',JSON.stringify(this.address));
    }
    handleNext(event){
        this.dispatchEvent(new CustomEvent('next'));
    }
    handlePrevious(event){
        this.dispatchEvent(new CustomEvent('previous'));
    }
}