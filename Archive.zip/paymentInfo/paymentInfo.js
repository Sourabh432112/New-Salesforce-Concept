import { LightningElement,track } from 'lwc';
export default class PaymentInfo extends LightningElement {
    @track paymentInfo={
        cardName:'',
        cardNumber:null,
        expiryMonth:null,
        expiryYear:null,
        cvv:null
    };

    handleChange(event){
        this.paymentInfo[event.target.name] = event.target.value;
        console.log('evet---',this.paymentInfo[event.target.name]);
    }
    submit(event){
        console.log('event---',event);
        console.log('event---',JSON.stringify(this.paymentInfo));
    }
    handleNext(event){
        this.dispatchEvent(new CustomEvent('next'));
    }
    handlePrevious(event){
        this.dispatchEvent(new CustomEvent('previous'));
    }
}