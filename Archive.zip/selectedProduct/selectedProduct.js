import { LightningElement,api } from 'lwc';
export default class SelectedProduct extends LightningElement {
    @api orderForm;

    handleQtyChange(event){
        try{
            const id = event.target.dataset.id;
            const value = event.target.value;

            this.orderForm = {
                ...this.orderForm,
                selectedProduct: this.orderForm.selectedProduct.map(p =>
                    p.Id === id
                        ? { ...p, quantity: value }
                        : p
                )
            };

console.log('quantity---', JSON.stringify(this.orderForm.selectedProduct));


        }catch(e){
            console.log('error--',e);
        }

    }
    handleNext(event){
        this.dispatchEvent(new CustomEvent('update',{
            detail:{
                key:'selectedProduct',
                value:this.orderForm.selectedProduct
            }
        }));
        this.dispatchEvent(new CustomEvent('next'));
    }
    handlePrevious(event){
        this.dispatchEvent(new CustomEvent('previous'));
    }
}