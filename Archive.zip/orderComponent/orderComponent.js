import { LightningElement,track } from 'lwc';
export default class OrderComponent extends LightningElement {
    currentStep ="1";
    @track orderForm ={
        selectedProduct :[]
    }

        handleChange(event){
                try{
                        const{key,value} = event.detail;
                        this.orderForm[key] = value;
                }catch(e){
                       
                }
        }

        handleNext(){
                try{
                        this.currentStep = (parseInt(this.currentStep, 10) + 1).toString();
                }catch(e){
                }
                
        }
        get stage1(){
                return this.currentStep === "1";
        }
        get stage2(){
                return this.currentStep === "2";
        }
        get stage3(){
                return this.currentStep ==='3';
        }
        get stage4(){
                return this.currentStep ==='4';
        }
        get stage5(){
                return this.currentStep ==='5';
        }
        handlePrevious(){
                this.currentStep = (parseInt(this.currentStep, 10) - 1).toString();
        }
}