import { LightningElement,api } from 'lwc';
export default class OrderSummary extends LightningElement {
    @api orderForm;

    connectedCallback(){
        console.log('orderForm---',JSON.stringify(this.orderForm));
    }
    handleNext(event){
        this.dispatchEvent(new CustomEvent('next'));
    }
    handlePrevious(event){
        this.dispatchEvent(new CustomEvent('previous'));
    }
}