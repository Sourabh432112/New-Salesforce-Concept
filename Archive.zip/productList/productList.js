import { LightningElement,track,wire } from 'lwc';
import getProductList from '@salesforce/apex/ProductList.getProductList';
export default class ProductList extends LightningElement {
    @track productList =[];
    @track selectedProduct=[];

    @wire(getProductList) wiredData({data,error}){
        if(data){
            this.productList = data;
        }
        if(error){
            
        }
    }

    selectProduct(event){
        const id = event.target.dataset.id;
        const product = this.productList.find(p=> id === p.Id);
        this.selectedProduct.push(product);
        console.log('product---',product);
    }
    
    handleNext(event){
        console.log('this.productList ---',this.selectedProduct );
        try{
            this.dispatchEvent(new CustomEvent('selectedproduct',{
                detail:{
                    key:'selectedProduct',
                    value:this.selectedProduct
                }
            }));
            this.dispatchEvent(new CustomEvent('next'));
        }catch(e){
            console.log('error---',json.stringify(e));
        }
    }

}